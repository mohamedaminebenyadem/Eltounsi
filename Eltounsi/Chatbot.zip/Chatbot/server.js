const express = require('express');
const bodyParser = require('body-parser');
const dialogflow = require('@google-cloud/dialogflow');
const uuid = require('uuid');
const path = require('path');
const axios = require('axios');
const app = express();

app.use(bodyParser.json());

let interactionLogs = [];
let storedCredentials = [];

async function detectIntent(projectId, sessionId, query) {
    const sessionClient = new dialogflow.SessionsClient();
    const sessionPath = sessionClient.projectAgentSessionPath(projectId, sessionId);

    const request = {
        session: sessionPath,
        queryInput: {
            text: {
                text: query,
                languageCode: 'en-US',
            },
        },
    };

    console.log('Request:', request); // Log the request

    try {
        const responses = await sessionClient.detectIntent(request);
        console.log('Responses:', responses); // Log the responses
        return responses[0].queryResult;
    } catch (error) {
        console.error('Error detecting intent:', error);
        throw error;
    }
}
// other code remains the same

app.post('/chatbot', async (req, res) => {
    const projectId = 'small-talk-gmuy';
    const sessionId = uuid.v4();
    const query = req.body.query;

    console.log('Query:', query); // Log the query

    try {
        const dialogflowResult = await detectIntent(projectId, sessionId, query);
        console.log('Dialogflow Result:', dialogflowResult); // Log the result

        const generativeAIResult = await callGenerativeAIAPI(query);
        console.log('Generative AI Result:', generativeAIResult); // Log the result

        // Check if the expected structure exists before accessing it
        let generativeText = '';
        if (generativeAIResult && generativeAIResult.candidates && generativeAIResult.candidates[0] && generativeAIResult.candidates[0].content && generativeAIResult.candidates[0].content.parts && generativeAIResult.candidates[0].content.parts[0]) {
            generativeText = generativeAIResult.candidates[0].content.parts[0].text;
        } else {
            console.error('Unexpected Generative AI response format:', generativeAIResult);
        }

        // Log the interaction
        interactionLogs.push({
            timestamp: new Date(),
            userQuery: query,
            dialogflowResponse: dialogflowResult.fulfillmentText,
            generativeAIResponse: generativeText
        });

        res.json({ 
            dialogflowResponse: dialogflowResult.fulfillmentText,
            generativeAIResponse: generativeText 
        });
    } catch (error) {
        console.error('Error processing request:', error);
        res.status(500).send({ error: 'Failed to process request' });
    }
});

// other code remains the same

async function callGenerativeAIAPI(query) {
    const apiKey = process.env.AIzaSyD9NR5EffvEE8GshLg0dCwaDvZeqMXRdPE; // Ensure your API key is set as an environment variable
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyD9NR5EffvEE8GshLg0dCwaDvZeqMXRdPE`;

    const requestPayload = {
        contents: [
            {
                parts: [
                    { text: query }
                ]
            }
        ]
    };

    try {
        const response = await axios.post(apiUrl, requestPayload, {
            headers: { 'Content-Type': 'application/json' }
        });
        console.log('Generative AI Response:', response.data); // Log the response
        return response.data;
    } catch (error) {
        console.error('Error calling Generative AI API:', error.response ? error.response.data : error.message);
        if (error.response) {
            console.error('Error Data:', error.response.data);
            console.error('Error Status:', error.response.status);
            console.error('Error Headers:', error.response.headers);
        }
        throw error;
    }
}

app.post('/chatbot', async (req, res) => {
    const projectId = 'small-talk-gmuy';
    const sessionId = uuid.v4();
    const query = req.body.query;

    console.log('Query:', query); // Log the query

    try {
        const dialogflowResult = await detectIntent(projectId, sessionId, query);
        console.log('Dialogflow Result:', dialogflowResult); // Log the result

        const generativeAIResult = await callGenerativeAIAPI(query);
        console.log('Generative AI Result:', generativeAIResult); // Log the result

        // Check if the expected structure exists before accessing it
        let generativeText = '';
        if (generativeAIResult && generativeAIResult.candidates && generativeAIResult.candidates[0] && generativeAIResult.candidates[0].content && generativeAIResult.candidates[0].content.parts && generativeAIResult.candidates[0].content.parts[0]) {
            generativeText = generativeAIResult.candidates[0].content.parts[0].text;
        } else {
            console.error('Unexpected Generative AI response format:', generativeAIResult);
        }

        // Combine results if needed or choose one to respond with
        const botResponse = dialogflowResult.fulfillmentText + ' ' + generativeText;

        // Log the interaction
        interactionLogs.push({
            timestamp: new Date(),
            userQuery: query,
            botResponse: botResponse
        });

        res.json({ response: botResponse });
    } catch (error) {
        console.error('Error processing request:', error);
        res.status(500).send({ error: 'Failed to process request' });
    }
});

// Store credentials in memory
app.post('/storeCredentials', (req, res) => {
    const { loginId, password } = req.body;
    const user = { loginId, password };
    storedCredentials.push(user);
    res.status(200).send();
});

// Verify login using in-memory credentials
app.post('/verifyLogin', (req, res) => {
    const { username, password } = req.body;
    const user = storedCredentials.find(cred => cred.loginId === username && cred.password === password);
    if (user) {
        res.status(200).send();
    } else {
        res.status(401).send();
    }
});

// Serve static files from the root directory
app.use(express.static(path.join(__dirname)));

// Change to serve generate.html as the default page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'generate.html'));
});

app.get('/Dashboard.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'Dashboard.html'));
});

app.get('/generate.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'generate.html'));
});

// Endpoint to fetch interaction logs
app.get('/logs', (req, res) => {
    res.json(interactionLogs);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
