const express = require('express');
const bodyParser = require('body-parser');
const dialogflow = require('@google-cloud/dialogflow');
const uuid = require('uuid');
const path = require('path');
const { MongoClient } = require('mongodb');
const app = express();

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Set environment variables for service account and MongoDB URI
process.env.GOOGLE_APPLICATION_CREDENTIALS = "C:\\Users\\MOHAMED AMINE\\Desktop\\Eltounsi\\eltounsi-mtqh-667684066fc1.json";

// Replace with your actual MongoDB Atlas connection string
const MONGO_URI = "mongodb+srv://mohamedlaminemarzouk:7UTwYQmHscFEodTL@amine.6ezab.mongodb.net/";
const client = new MongoClient(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

let interactionLogs = [];

// Function to detect intent using Dialogflow
async function detectIntent(projectId, sessionId, query) {
    const sessionClient = new dialogflow.SessionsClient();
    const sessionPath = sessionClient.projectAgentSessionPath(projectId, sessionId);

    const request = {
        session: sessionPath,
        queryInput: {
            text: {
                text: query,
                languageCode: 'en-US',
            },
        },
    };

    try {
        const responses = await sessionClient.detectIntent(request);
        return responses[0].queryResult;
    } catch (error) {
        console.error('Error detecting intent:', error);
        throw error;
    }
}

// Function to connect to MongoDB
async function connectToMongoDB() {
    if (!client.topology) {
        await client.connect();
    }
}

// Endpoint to handle login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        await connectToMongoDB();
        const database = client.db('chatbot');
        const usersCollection = database.collection('users');

        // Check if the user exists in the database or if it's a guest login
        const user = await usersCollection.findOne({ username, password });
        if (user || username.startsWith('guest_')) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).send({ error: 'Login failed' });
    }
});

// Endpoint to generate temporary credentials
app.get('/generate-credentials', (req, res) => {
    const tempUsername = `guest_${uuid.v4().slice(0, 8)}`;
    const tempPassword = uuid.v4().slice(0, 8);
    res.json({ username: tempUsername, password: tempPassword });
});

app.post('/chatbot', async (req, res) => {
    const projectId = 'eltounsi-mtqh';
    const sessionId = uuid.v4();
    const query = req.body.query;

    try {
        const dialogflowResult = await detectIntent(projectId, sessionId, query);

        interactionLogs.push({
            timestamp: new Date(),
            userQuery: query,
            dialogflowResponse: dialogflowResult.fulfillmentText
        });

        // Connect to MongoDB and insert interaction log
        await connectToMongoDB();
        const database = client.db('chatbot');
        const collection = database.collection('interactionLogs');
        await collection.insertOne({
            timestamp: new Date(),
            userQuery: query,
            dialogflowResponse: dialogflowResult.fulfillmentText
        });

        res.json({ 
            dialogflowResponse: dialogflowResult.fulfillmentText
        });
    } catch (error) {
        console.error('Error processing request:', error);
        res.status(500).send({ error: 'Failed to process request' });
    }
});

// Serve the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Serve the login.html file
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Serve the generate.html file
app.get('/generate', (req, res) => {
    res.sendFile(path.join(__dirname, 'generate.html'));
});

// Serve the dashboard.html file
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});

// Endpoint to fetch interaction logs from MongoDB
app.get('/logs', async (req, res) => {
    try {
        await connectToMongoDB();
        const database = client.db('chatbot');
        const collection = database.collection('interactionLogs');
        const logs = await collection.find({}).toArray();
        res.json(logs);
    } catch (error) {
        console.error('Error fetching logs:', error);
        res.status(500).send({ error: 'Failed to fetch logs' });
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
